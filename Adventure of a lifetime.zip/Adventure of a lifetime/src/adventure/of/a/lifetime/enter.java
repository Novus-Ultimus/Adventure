package adventure.of.a.lifetime;

public class enter {

	public void waterfall() {
		System.out.print("You jump into the the lake and before you you see a shiny pearl at the bottom of the "
				+ "lake,\nyou feel an increasing draw to the pearl the longer you look at it\n\n");
	}

	public void chainhouse() {
		// TODO Auto-generated method stub

	}

}
