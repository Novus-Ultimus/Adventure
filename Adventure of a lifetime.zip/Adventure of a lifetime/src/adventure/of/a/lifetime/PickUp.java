package adventure.of.a.lifetime;

public class PickUp {

	public void NA() {
		System.out.print("There is nothing to pick up");

	}
	
}
//public PickUp () {
//	System.out.print("");
//	return null;
//}