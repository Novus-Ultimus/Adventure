package adventure.of.a.lifetime;

import java.util.concurrent.TimeUnit;

public class Dance {

	public void NA() {
		System.out.print("Nothing happens\n");
		
	}
	
	public void slenderdance() {
		System.out.print("He doesn't appear to be impressed. He continues to stare at you\n");
		
	}

	public void house() {
		System.out.print("You can hear clapping from inside the house. Someone seems to be impressed by your "
                        + "dancing\n");
		
	}

	public void waterfall() throws InterruptedException {
		// TODO Auto-generated method stub
 System.out.print("");
 TimeUnit.SECONDS.sleep(1);
 System.out.print("");
	}

	public void villagerdance() {
		// TODO Auto-generated method stub

	}
	
	public void leatherdance1() {
		//TODO
	}
	
	public void leathersing1() {
		//TODO
	}

}
