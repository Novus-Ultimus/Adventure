package adventure.of.a.lifetime;

import java.io.IOException;

public class AdventureOfALifetime {

    public static void main(String[] args) throws InterruptedException, IOException {
        System.out.println("Good Evening, Ladies and Gents, I hope have Fun in our World of Horror");
        Start advS = new Start();
        advS.Game();
    }

}
